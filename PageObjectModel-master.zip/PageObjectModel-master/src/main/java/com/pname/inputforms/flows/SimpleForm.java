package com.pname.inputforms.flows;

import com.pname.inputforms.pages.SimpleInput_Pages;

public class SimpleForm {

	public void validateSimpleInputField() {
		SimpleInput_Pages.navigateToSimpleForm();
		SimpleInput_Pages.enterMsg("Sample Testing");
		SimpleInput_Pages.clickShowMsg();
	}
}
