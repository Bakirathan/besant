package com.pname.inputforms.pages;

import org.openqa.selenium.By;

import com.pname.base.TestBase;

public class SimpleInput_Pages extends TestBase {
	public static final By ENTER_MSG = By.id("user-message");
	public static final By SHOW_MSG_BTN = By.xpath("//*[text()='Show Message']");

	public static void enterMsg(String msg) {
		driver.findElement(ENTER_MSG).sendKeys(msg);
	}

	public static void clickShowMsg() {
		driver.findElement(SHOW_MSG_BTN).click();
	}

	public static void navigateToSimpleForm() {
		driver.get("https://www.seleniumeasy.com/test/basic-first-form-demo.html");
	}
}
