package com.pname.inputforms.tests;

import org.testng.annotations.Test;

import com.pname.base.TestBase;
import com.pname.inputforms.flows.SimpleForm;

public class InputForm extends TestBase{
	SimpleForm simpleForm;
	
	@Test(priority = 1)
	public void verify_Single_Input_Field() throws InterruptedException {
		simpleForm = new SimpleForm();
		simpleForm.validateSimpleInputField();
		Thread.sleep(10000);
	}

}
